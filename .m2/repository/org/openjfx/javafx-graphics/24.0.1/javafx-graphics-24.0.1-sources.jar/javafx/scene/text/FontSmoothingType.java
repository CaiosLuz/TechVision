/*
 * Copyright (c) 2012, 2013, Oracle and/or its affiliates. All rights reserved.
 * DO NOT ALTER OR REMOVE COPYRIGHT NOTICES OR THIS FILE HEADER.
 *
 * This code is free software; you can redistribute it and/or modify it
 * under the terms of the GNU General Public License version 2 only, as
 * published by the Free Software Foundation.  Oracle designates this
 * particular file as subject to the "Classpath" exception as provided
 * by Oracle in the LICENSE file that accompanied this code.
 *
 * This code is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
 * FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License
 * version 2 for more details (a copy is included in the LICENSE file that
 * accompanied this code).
 *
 * You should have received a copy of the GNU General Public License version
 * 2 along with this work; if not, write to the Free Software Foundation,
 * Inc., 51 Franklin St, Fifth Floor, Boston, MA 02110-1301 USA.
 *
 * Please contact Oracle, 500 Oracle Parkway, Redwood Shores, CA 94065 USA
 * or visit www.oracle.com if you need additional information or have any
 * questions.
 */

package javafx.scene.text;

/**
 * The {@code FontSmoothingType} enum is used to specify the preferred
 * mechanism used to smooth the edges of fonts for on-screen text.
 * @since JavaFX 2.1
 */

public enum FontSmoothingType {

    /**
     * Specifies the default gray scale smoothing, which is most
     * suitable for graphics and animation uses.
     */
    GRAY,

   /**
     * Specifies sub-pixel LCD text, which utilises characteristics
     * of digital LCD display panels to achieve increased pixel
     * resolution. This mode is generally appropriate where the
     * important factor is legibility of static text, particularly
     * at small sizes.
     * <p>
     * A request for LCD text is a 'hint', since the implementation
     * may need to ignore it under conditions such as compositing modes
     * which do not support it. It follow that where LCD text is important
     * that the application should avoid use of effects, transparency etc.
     */
    LCD

}
